from app import create_app

app = create_app()

if __name__ == "__main__":
    from waitress import serve
    print("SG ERP+MRP is running at http://127.0.0.1:8080")
    serve(app, host="127.0.0.1", port=8080, threads=8)
