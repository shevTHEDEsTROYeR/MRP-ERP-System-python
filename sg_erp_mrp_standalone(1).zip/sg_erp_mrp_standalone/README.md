# SG ERP + MRP Standalone

A local, server-backed ERP/MRP application with secure login, role authorization, embedded SQLite, inventory, customers, suppliers, bills of materials, production orders, stock posting, user management, and audit logging.

## Why Flask is included
PyScript runs inside the browser. Browser code cannot safely hide database credentials, enforce authorization, or directly protect an embedded SQL database. This package therefore uses:

- **Flask/Python** as the trusted local server and security boundary
- **SQLite** as the embedded SQL database
- **HTML/CSS/JavaScript** for the interface
- **PyScript** for browser-side KPI analysis
- **Waitress** as the standalone production-style local WSGI server

## Security controls included

- Scrypt password hashing through Werkzeug
- Server-side authorization checks and role-based access
- HTTP-only, SameSite session cookie
- Automatic secret-key generation
- CSRF protection on state-changing forms
- Account lockout after five failed attempts
- Parameterized SQL statements
- Content Security Policy and security headers
- Sector-level data filtering
- Audit logging
- No default username or password

## Windows installation

1. Install Python 3.11 or newer from python.org. During installation, tick **Add Python to PATH**.
2. Extract this ZIP to a normal folder, for example `C:\SG_ERP_MRP`.
3. Open that folder in File Explorer.
4. Click the address bar, type `cmd`, and press Enter.
5. Run:

```bat
python -m venv .venv
.venv\Scriptsctivate
python -m pip install --upgrade pip
pip install -r requirements.txt
python run.py
```

6. Open `http://127.0.0.1:8080` in your browser.
7. The first page asks you to create the first administrator. Use a unique password of at least 12 characters containing uppercase, lowercase, number, and symbol.

## Later starts

```bat
cd C:\SG_ERP_MRP
.venv\Scriptsctivate
python run.py
```

## Database and backup

The embedded database is created at `instance/erp.sqlite3`. Stop the application before copying this file as a backup. Also preserve `instance/secret.key`; existing sessions depend on it.

## Roles

- `admin`: users, inventory, MRP, partners, audit
- `manager`: inventory, MRP completion, partners, audit
- `operator`: inventory transactions and partner entry
- `viewer`: read-only operational access

## Typical workflow

1. Add raw materials and finished goods under Inventory.
2. Add suppliers and customers.
3. Create BOM lines under MRP.
4. Create a production order.
5. Receive raw-material stock.
6. Complete the production order; the system consumes components and adds finished stock in one database transaction.

## Industry options
Manufacturing, Food & Beverage, Pharmaceutical, Retail, Apparel, Construction, Automotive, Electronics, Agriculture, and Distribution. Administrators can create users assigned to different sectors.

## Important production note
This is a legitimate standalone baseline, not a browser-only mock-up. However, any deployment over a network or the public internet requires HTTPS, external backups, OS hardening, malware protection, database migration procedures, monitored logs, and a formal security review. Do not expose port 8080 directly to the internet.
