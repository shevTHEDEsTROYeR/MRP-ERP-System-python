import os
from flask import Flask
from .db import init_app, init_db
from .security import security_headers


def create_app():
    app = Flask(__name__, instance_relative_config=True)
    os.makedirs(app.instance_path, exist_ok=True)
    secret_file = os.path.join(app.instance_path, "secret.key")
    if not os.path.exists(secret_file):
        with open(secret_file, "wb") as f:
            f.write(os.urandom(32))
    with open(secret_file, "rb") as f:
        secret = f.read()

    app.config.update(
        SECRET_KEY=secret,
        DATABASE=os.path.join(app.instance_path, "erp.sqlite3"),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=False,
        PERMANENT_SESSION_LIFETIME=1800,
        MAX_CONTENT_LENGTH=8 * 1024 * 1024,
    )
    init_app(app)
    with app.app_context():
        init_db()

    from .routes import bp
    app.register_blueprint(bp)
    app.after_request(security_headers)
    return app
