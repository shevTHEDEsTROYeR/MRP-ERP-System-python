from pyscript import document
cards = document.querySelectorAll(".cards article b")
values = [float(card.innerText or 0) for card in cards]
message = f"Sector snapshot: {int(values[0])} items, {int(values[1])} low-stock alerts, and {int(values[2])} open production orders."
document.querySelector("#py-output").innerText = message
