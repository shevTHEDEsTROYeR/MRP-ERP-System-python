"use strict";
// Prevent accidental double submissions.
document.querySelectorAll("form").forEach(form=>form.addEventListener("submit",()=>{const b=form.querySelector("button[type=submit],button:not([type])");if(b){b.disabled=true;setTimeout(()=>b.disabled=false,2500)}}));
