import secrets
from functools import wraps
from flask import session, request, abort, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash


def hash_password(password):
    return generate_password_hash(password, method="scrypt")

def verify_password(password_hash, password):
    return check_password_hash(password_hash, password)

def csrf_token():
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token

def validate_csrf():
    supplied = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")
    if not supplied or not secrets.compare_digest(supplied, session.get("csrf_token", "")):
        abort(400, "Invalid CSRF token")

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please sign in.", "warning")
            return redirect(url_for("main.login"))
        return view(*args, **kwargs)
    return wrapped

def roles_required(*roles):
    def deco(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if session.get("role") not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return deco

def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = ("default-src 'self'; script-src 'self' https://pyscript.net; "
        "style-src 'self' 'unsafe-inline' https://pyscript.net; connect-src 'self' https://pyscript.net; "
        "img-src 'self' data:; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
    return response
