from datetime import datetime, timedelta, timezone
import re
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, abort
from .db import get_db
from .security import hash_password, verify_password, csrf_token, validate_csrf, login_required, roles_required

bp = Blueprint("main", __name__)
SECTORS = ["Manufacturing", "Food & Beverage", "Pharmaceutical", "Retail", "Apparel", "Construction", "Automotive", "Electronics", "Agriculture", "Distribution"]

def audit(action, entity, entity_id=None):
    db=get_db(); db.execute("INSERT INTO audit_logs(user_id,action,entity,entity_id,ip_address) VALUES(?,?,?,?,?)",(session.get('user_id'),action,entity,str(entity_id) if entity_id else None,request.remote_addr)); db.commit()

def sector_filter():
    return session.get("sector")

@bp.app_context_processor
def inject_globals():
    return {"csrf_token": csrf_token, "sectors": SECTORS}

@bp.route("/")
def index():
    return redirect(url_for("main.dashboard") if session.get("user_id") else url_for("main.login"))

@bp.route("/setup", methods=["GET","POST"])
def setup():
    db=get_db()
    if db.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]:
        return redirect(url_for("main.login"))
    if request.method=="POST":
        validate_csrf(); username=request.form["username"].strip(); email=request.form["email"].strip().lower(); password=request.form["password"]; sector=request.form["sector"]
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,30}", username): flash("Username must be 3-30 characters.","danger")
        elif len(password)<12 or not re.search(r"[A-Z]",password) or not re.search(r"[a-z]",password) or not re.search(r"\d",password) or not re.search(r"[^A-Za-z0-9]",password): flash("Use 12+ characters with upper, lower, number, and symbol.","danger")
        elif sector not in SECTORS: flash("Invalid sector.","danger")
        else:
            db.execute("INSERT INTO users(username,email,password_hash,role,sector) VALUES(?,?,?,?,?)",(username,email,hash_password(password),"admin",sector)); db.commit(); flash("Administrator created. Sign in.","success"); return redirect(url_for("main.login"))
    return render_template("setup.html")

@bp.route("/login", methods=["GET","POST"])
def login():
    db=get_db()
    if db.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]==0: return redirect(url_for("main.setup"))
    if request.method=="POST":
        validate_csrf(); identity=request.form["identity"].strip(); password=request.form["password"]
        user=db.execute("SELECT * FROM users WHERE username=? OR email=?",(identity,identity.lower())).fetchone()
        now=datetime.now(timezone.utc)
        if user and user["locked_until"]:
            try:
                if datetime.fromisoformat(user["locked_until"])>now: flash("Account temporarily locked. Try later.","danger"); return render_template("login.html")
            except ValueError: pass
        if not user or not user["is_active"] or not verify_password(user["password_hash"],password):
            if user:
                attempts=user["failed_attempts"]+1; locked=(now+timedelta(minutes=15)).isoformat() if attempts>=5 else None
                db.execute("UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?",(0 if locked else attempts,locked,user["id"])); db.commit()
            flash("Invalid credentials.","danger"); return render_template("login.html")
        db.execute("UPDATE users SET failed_attempts=0,locked_until=NULL WHERE id=?",(user["id"],)); db.commit(); session.clear(); session.permanent=True
        session.update(user_id=user["id"],username=user["username"],role=user["role"],sector=user["sector"]); csrf_token(); audit("login","user",user["id"]); return redirect(url_for("main.dashboard"))
    return render_template("login.html")

@bp.post("/logout")
@login_required
def logout():
    validate_csrf(); audit("logout","user",session.get("user_id")); session.clear(); flash("Signed out safely.","success"); return redirect(url_for("main.login"))

@bp.route("/dashboard")
@login_required
def dashboard():
    db=get_db(); sec=sector_filter()
    stats={
      "items":db.execute("SELECT COUNT(*) c FROM items WHERE sector=?",(sec,)).fetchone()["c"],
      "low":db.execute("SELECT COUNT(*) c FROM items WHERE sector=? AND quantity<=reorder_level",(sec,)).fetchone()["c"],
      "production":db.execute("SELECT COUNT(*) c FROM production_orders p JOIN items i ON i.id=p.finished_item_id WHERE i.sector=? AND p.status IN ('planned','released')",(sec,)).fetchone()["c"],
      "customers":db.execute("SELECT COUNT(*) c FROM customers WHERE sector=?",(sec,)).fetchone()["c"]}
    recent=db.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 8").fetchall()
    return render_template("dashboard.html",stats=stats,recent=recent)

@bp.route("/items", methods=["GET","POST"])
@login_required
def items():
    db=get_db(); sec=sector_filter()
    if request.method=="POST":
        if session.get("role") not in ("admin","manager","operator"): abort(403)
        validate_csrf()
        try:
            cur=db.execute("INSERT INTO items(sku,name,item_type,unit,quantity,reorder_level,unit_cost,sector) VALUES(?,?,?,?,?,?,?,?)",(request.form["sku"].strip(),request.form["name"].strip(),request.form["item_type"],request.form["unit"].strip(),float(request.form["quantity"]),float(request.form["reorder_level"]),float(request.form["unit_cost"]),sec)); db.commit(); audit("create","item",cur.lastrowid); flash("Item added.","success")
        except Exception as e: db.rollback(); flash("Could not add item. SKU may already exist or values may be invalid.","danger")
        return redirect(url_for("main.items"))
    rows=db.execute("SELECT * FROM items WHERE sector=? ORDER BY id DESC",(sec,)).fetchall(); return render_template("items.html",items=rows)

@bp.post("/stock/<int:item_id>")
@login_required
@roles_required("admin","manager","operator")
def stock(item_id):
    validate_csrf(); db=get_db(); item=db.execute("SELECT * FROM items WHERE id=? AND sector=?",(item_id,sector_filter())).fetchone()
    if not item: abort(404)
    qty=float(request.form["quantity"]); movement=request.form["movement_type"]
    delta=qty if movement in ("receipt","production_in") else -qty if movement in ("issue","production_out") else qty
    if item["quantity"]+delta<0: flash("Insufficient stock.","danger"); return redirect(url_for("main.items"))
    db.execute("UPDATE items SET quantity=quantity+? WHERE id=?",(delta,item_id)); cur=db.execute("INSERT INTO stock_movements(item_id,movement_type,quantity,reference,created_by) VALUES(?,?,?,?,?)",(item_id,movement,delta,request.form.get("reference",""),session["user_id"])); db.commit(); audit("stock_movement","item",item_id); flash("Stock updated.","success"); return redirect(url_for("main.items"))

@bp.route("/partners", methods=["GET","POST"])
@login_required
def partners():
    db=get_db(); sec=sector_filter()
    if request.method=="POST":
        if session.get("role") not in ("admin","manager","operator"): abort(403)
        validate_csrf(); kind=request.form["kind"]; table="customers" if kind=="customer" else "suppliers"
        cur=db.execute(f"INSERT INTO {table}(name,email,phone,sector) VALUES(?,?,?,?)",(request.form["name"].strip(),request.form.get("email",""),request.form.get("phone",""),sec)); db.commit(); audit("create",kind,cur.lastrowid); flash(f"{kind.title()} added.","success"); return redirect(url_for("main.partners"))
    customers=db.execute("SELECT * FROM customers WHERE sector=? ORDER BY id DESC",(sec,)).fetchall(); suppliers=db.execute("SELECT * FROM suppliers WHERE sector=? ORDER BY id DESC",(sec,)).fetchall(); return render_template("partners.html",customers=customers,suppliers=suppliers)

@bp.route("/mrp", methods=["GET","POST"])
@login_required
def mrp():
    db=get_db(); sec=sector_filter()
    if request.method=="POST":
        if session.get("role") not in ("admin","manager"): abort(403)
        validate_csrf(); action=request.form["action"]
        if action=="bom":
            db.execute("INSERT OR REPLACE INTO boms(finished_item_id,component_item_id,quantity_required) VALUES(?,?,?)",(int(request.form["finished_item_id"]),int(request.form["component_item_id"]),float(request.form["quantity_required"])))
        else:
            cur=db.execute("INSERT INTO production_orders(order_no,finished_item_id,planned_qty,due_date,created_by) VALUES(?,?,?,?,?)",(request.form["order_no"].strip(),int(request.form["finished_item_id"]),float(request.form["planned_qty"]),request.form.get("due_date") or None,session["user_id"])); audit("create","production_order",cur.lastrowid)
        db.commit(); flash("MRP record saved.","success"); return redirect(url_for("main.mrp"))
    items=db.execute("SELECT * FROM items WHERE sector=? ORDER BY name",(sec,)).fetchall(); boms=db.execute("SELECT b.*,f.name finished_name,c.name component_name FROM boms b JOIN items f ON f.id=b.finished_item_id JOIN items c ON c.id=b.component_item_id WHERE f.sector=?",(sec,)).fetchall(); orders=db.execute("SELECT p.*,i.name item_name FROM production_orders p JOIN items i ON i.id=p.finished_item_id WHERE i.sector=? ORDER BY p.id DESC",(sec,)).fetchall(); return render_template("mrp.html",items=items,boms=boms,orders=orders)

@bp.post("/mrp/complete/<int:order_id>")
@login_required
@roles_required("admin","manager")
def complete_order(order_id):
    validate_csrf(); db=get_db(); order=db.execute("SELECT p.*,i.sector FROM production_orders p JOIN items i ON i.id=p.finished_item_id WHERE p.id=?",(order_id,)).fetchone()
    if not order or order["sector"]!=sector_filter(): abort(404)
    if order["status"]=="completed": return redirect(url_for("main.mrp"))
    components=db.execute("SELECT b.*,i.quantity stock,i.name FROM boms b JOIN items i ON i.id=b.component_item_id WHERE b.finished_item_id=?",(order["finished_item_id"],)).fetchall()
    shortages=[c["name"] for c in components if c["stock"] < c["quantity_required"]*order["planned_qty"]]
    if shortages: flash("Cannot complete. Shortage: "+", ".join(shortages),"danger"); return redirect(url_for("main.mrp"))
    for c in components:
        used=c["quantity_required"]*order["planned_qty"]; db.execute("UPDATE items SET quantity=quantity-? WHERE id=?",(used,c["component_item_id"])); db.execute("INSERT INTO stock_movements(item_id,movement_type,quantity,reference,created_by) VALUES(?,?,?,?,?)",(c["component_item_id"],"production_out",-used,order["order_no"],session["user_id"]))
    db.execute("UPDATE items SET quantity=quantity+? WHERE id=?",(order["planned_qty"],order["finished_item_id"])); db.execute("INSERT INTO stock_movements(item_id,movement_type,quantity,reference,created_by) VALUES(?,?,?,?,?)",(order["finished_item_id"],"production_in",order["planned_qty"],order["order_no"],session["user_id"])); db.execute("UPDATE production_orders SET status='completed' WHERE id=?",(order_id,)); db.commit(); audit("complete","production_order",order_id); flash("Production completed and inventory posted.","success"); return redirect(url_for("main.mrp"))

@bp.route("/users", methods=["GET","POST"])
@login_required
@roles_required("admin")
def users():
    db=get_db()
    if request.method=="POST":
        validate_csrf(); password=request.form["password"]
        if len(password)<12: flash("Password must be at least 12 characters.","danger")
        else:
            try: db.execute("INSERT INTO users(username,email,password_hash,role,sector) VALUES(?,?,?,?,?)",(request.form["username"].strip(),request.form["email"].strip().lower(),hash_password(password),request.form["role"],request.form["sector"])); db.commit(); flash("User created.","success")
            except Exception: db.rollback(); flash("Username or email already exists.","danger")
        return redirect(url_for("main.users"))
    return render_template("users.html",users=db.execute("SELECT id,username,email,role,sector,is_active,created_at FROM users ORDER BY id DESC").fetchall())

@bp.route("/audit")
@login_required
@roles_required("admin","manager")
def audit_page():
    rows=get_db().execute("SELECT a.*,u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 300").fetchall(); return render_template("audit.html",logs=rows)
