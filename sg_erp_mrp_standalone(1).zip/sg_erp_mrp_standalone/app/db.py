import sqlite3
from flask import current_app, g

SCHEMA = r"""
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','manager','operator','viewer')),
 sector TEXT NOT NULL,
 is_active INTEGER NOT NULL DEFAULT 1,
 failed_attempts INTEGER NOT NULL DEFAULT 0,
 locked_until TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 action TEXT NOT NULL,
 entity TEXT NOT NULL,
 entity_id TEXT,
 ip_address TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS items (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 sku TEXT NOT NULL UNIQUE,
 name TEXT NOT NULL,
 item_type TEXT NOT NULL CHECK(item_type IN ('raw_material','finished_good','service')),
 unit TEXT NOT NULL,
 quantity REAL NOT NULL DEFAULT 0,
 reorder_level REAL NOT NULL DEFAULT 0,
 unit_cost REAL NOT NULL DEFAULT 0,
 sector TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS suppliers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT,
 phone TEXT,
 sector TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS customers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT,
 phone TEXT,
 sector TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS boms (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 finished_item_id INTEGER NOT NULL,
 component_item_id INTEGER NOT NULL,
 quantity_required REAL NOT NULL CHECK(quantity_required > 0),
 UNIQUE(finished_item_id, component_item_id),
 FOREIGN KEY(finished_item_id) REFERENCES items(id) ON DELETE CASCADE,
 FOREIGN KEY(component_item_id) REFERENCES items(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS production_orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_no TEXT NOT NULL UNIQUE,
 finished_item_id INTEGER NOT NULL,
 planned_qty REAL NOT NULL CHECK(planned_qty > 0),
 status TEXT NOT NULL CHECK(status IN ('planned','released','completed','cancelled')) DEFAULT 'planned',
 due_date TEXT,
 created_by INTEGER,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(finished_item_id) REFERENCES items(id),
 FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS stock_movements (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 item_id INTEGER NOT NULL,
 movement_type TEXT NOT NULL CHECK(movement_type IN ('receipt','issue','adjustment','production_in','production_out')),
 quantity REAL NOT NULL,
 reference TEXT,
 created_by INTEGER,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(item_id) REFERENCES items(id),
 FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS sales_orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_no TEXT NOT NULL UNIQUE,
 customer_id INTEGER NOT NULL,
 total REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL CHECK(status IN ('draft','confirmed','fulfilled','cancelled')) DEFAULT 'draft',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES customers(id)
);
CREATE TABLE IF NOT EXISTS purchase_orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_no TEXT NOT NULL UNIQUE,
 supplier_id INTEGER NOT NULL,
 total REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL CHECK(status IN ('draft','approved','received','cancelled')) DEFAULT 'draft',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
);
"""

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    db.executescript(SCHEMA)
    db.commit()

def init_app(app):
    app.teardown_appcontext(close_db)
